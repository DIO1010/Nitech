#!/bin/sh
gcc ./main.c -o ./main
./main > output.txt
