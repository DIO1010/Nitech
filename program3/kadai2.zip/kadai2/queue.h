#ifndef QUEUE_H
#define QUEUE_H

// キューの構造体
typedef struct{
  int max; /* キューのサイズ */
  int num; /* 現在の要素数 */
  int front; /* 先頭要素カーソル */
  int rear; /* 末尾要素カーソル */
  int *que; /* キュー（の先頭要素へのポイント） */
}Queue;

// キューの初期化
int QueueAlloc(Queue *q, int max);

// キューの後始末
void QueueFree(Queue *Q);

// キューにデータをエンキュー
int QueueEnque(Queue *q, int x);

// キューからデータをデキュー
int QueueDeque(Queue *q,int *x);

// キューの大きさ
int QueueSize(const Queue *q);

// キューに蓄えられているデータ数
int QueueNo(const Queue *q);

// キューは空か
int QueueIsEmpty(const Queue *q);

// キューは満杯か
int QueueIsFull(const Queue *q);
#endif
